using System;
using OffWorkCountdown;

internal static class EngineTests
{
    private static int _passed;

    private static void Check(bool condition, string name)
    {
        if (!condition)
        {
            Console.WriteLine("FAIL  " + name);
            Environment.Exit(1);
        }
        _passed++;
        Console.WriteLine("ok    " + name);
    }

    private static void CheckEqual(string actual, string expected, string name)
    {
        Check(string.Equals(actual, expected, StringComparison.Ordinal),
            name + " (expected '" + expected + "', got '" + actual + "')");
    }

    private static void CheckNear(double actual, double expected, string name)
    {
        Check(Math.Abs(actual - expected) < 0.0001,
            name + " (expected " + expected + ", got " + actual + ")");
    }

    public static int Main()
    {
        DateTime wednesday = new DateTime(2026, 11, 11);
        DateTime saturday = new DateTime(2026, 11, 14);

        CountdownSnapshot before = CountdownEngine.Evaluate(
            wednesday.AddHours(8), 9 * 60, 18 * 60, true);
        Check(before.Mode == CountdownMode.BeforeWork, "08:00 is before work");
        CheckEqual(CountdownEngine.FormatDuration(before.Remaining, true), "01:00:00",
            "08:00 leaves one hour");
        CheckNear(before.Progress, 0.0, "before-work progress is zero");

        CountdownSnapshot start = CountdownEngine.Evaluate(
            wednesday.AddHours(9), 9 * 60, 18 * 60, true);
        Check(start.Mode == CountdownMode.Working, "09:00 starts work");
        CheckEqual(CountdownEngine.FormatDuration(start.Remaining, true), "09:00:00",
            "09:00 leaves nine hours");

        CountdownSnapshot noon = CountdownEngine.Evaluate(
            wednesday.AddHours(12), 9 * 60, 18 * 60, true);
        Check(noon.Mode == CountdownMode.Working, "12:00 is working");
        CheckEqual(CountdownEngine.FormatDuration(noon.Remaining, true), "06:00:00",
            "12:00 leaves six hours");
        CheckNear(noon.Progress, 1.0 / 3.0, "12:00 is one third through");

        CountdownSnapshot almost = CountdownEngine.Evaluate(
            wednesday.AddHours(17).AddMinutes(49).AddSeconds(59), 9 * 60, 18 * 60, true);
        Check(almost.Mode == CountdownMode.Working, "10m01s left is still normal work");

        CountdownSnapshot soon = CountdownEngine.Evaluate(
            wednesday.AddHours(17).AddMinutes(50), 9 * 60, 18 * 60, true);
        Check(soon.Mode == CountdownMode.Soon, "10m00s left enters the soon state");
        CheckEqual(CountdownEngine.FormatDuration(soon.Remaining, true), "00:10:00",
            "soon state keeps the exact countdown");

        CountdownSnapshot end = CountdownEngine.Evaluate(
            wednesday.AddHours(18), 9 * 60, 18 * 60, true);
        Check(end.Mode == CountdownMode.Overtime, "18:00 switches to overtime");
        CheckNear(end.Progress, 1.0, "overtime progress is full");

        CountdownSnapshot over = CountdownEngine.Evaluate(
            wednesday.AddHours(18).AddMinutes(42).AddSeconds(26), 9 * 60, 18 * 60, true);
        Check(over.Mode == CountdownMode.Overtime, "18:42 is overtime");
        CheckEqual(CountdownEngine.FormatDuration(over.Remaining, true), "00:42:26",
            "overtime duration is exact");

        CountdownSnapshot rest = CountdownEngine.Evaluate(
            saturday.AddHours(11), 9 * 60, 18 * 60, true);
        Check(rest.Mode == CountdownMode.RestDay, "Saturday is a rest day by default");

        CountdownSnapshot weekendShift = CountdownEngine.Evaluate(
            saturday.AddHours(11), 9 * 60, 18 * 60, false);
        Check(weekendShift.Mode == CountdownMode.Working,
            "weekend still counts when workdays-only is off");

        CountdownSnapshot custom = CountdownEngine.Evaluate(
            wednesday.AddHours(13), 13 * 60, 14 * 60, true);
        Check(custom.Mode == CountdownMode.Working, "custom one-hour shift is working");
        CheckEqual(CountdownEngine.FormatDuration(custom.Remaining, true), "01:00:00",
            "one-hour shift has one hour left");

        CheckEqual(CountdownEngine.FormatMinutes(9 * 60 + 5), "09:05",
            "minutes format with a leading zero");
        CheckEqual(CountdownEngine.FormatMinutes(18 * 60), "18:00",
            "evening minutes format");

        int parsed;
        Check(CountdownEngine.TryParseMinutes("09:00", out parsed) && parsed == 540,
            "parse 09:00");
        Check(CountdownEngine.TryParseMinutes("9:5", out parsed) && parsed == 545,
            "parse a loose 9:5");
        Check(CountdownEngine.TryParseMinutes("17：48", out parsed) && parsed == 1068,
            "parse full-width colon");
        Check(!CountdownEngine.TryParseMinutes("25:00", out parsed), "reject 25:00");
        Check(!CountdownEngine.TryParseMinutes("09:61", out parsed), "reject 09:61");
        Check(!CountdownEngine.TryParseMinutes("morning", out parsed), "reject words");

        CheckNear(CountdownEngine.Clamp01(-0.4), 0.0, "clamp below zero");
        CheckNear(CountdownEngine.Clamp01(1.4), 1.0, "clamp above one");

        Console.WriteLine();
        Console.WriteLine(_passed + " checks passed.");
        return 0;
    }
}
