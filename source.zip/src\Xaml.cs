using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Markup;

namespace OffWorkCountdown
{
    internal static class Xaml
    {
        public static object Load(string resourceName)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            using (Stream stream = assembly.GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                {
                    throw new InvalidOperationException("Missing XAML resource: " + resourceName);
                }
                return XamlReader.Load(stream);
            }
        }

        public static ResourceDictionary Theme()
        {
            ResourceDictionary dictionary = Load("OffWorkCountdown.ui.Theme.xaml") as ResourceDictionary;
            if (dictionary == null)
            {
                throw new InvalidOperationException("Theme.xaml is not a ResourceDictionary.");
            }
            return dictionary;
        }
    }
}
