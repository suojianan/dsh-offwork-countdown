using System;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Drawing = System.Drawing;
using WinForms = System.Windows.Forms;
using ContextMenu = System.Windows.Controls.ContextMenu;
using MenuItem = System.Windows.Controls.MenuItem;
using Application = System.Windows.Application;
using Color = System.Windows.Media.Color;
using FontFamily = System.Windows.Media.FontFamily;
using Path = System.IO.Path;

namespace OffWorkCountdown
{
    public sealed class WidgetWindow : Window
    {
        private const double WidgetWidth = 368;
        private const double WidgetHeight = 232;
        private const string IconResource = "OffWorkCountdown.assets.icon.ico";

        private readonly AppSettings _settings;
        private readonly bool _demoMode;
        private readonly bool _snapshotMode;
        private readonly DateTime? _demoNow;
        private readonly Grid _root;
        private readonly Border _glassBack;
        private readonly Grid _glowLayer;
        private readonly Button _gearButton;
        private readonly TextBlock _dateText;
        private readonly TextBlock _modeLabel;
        private readonly TextBlock _timeText;
        private readonly Canvas _progressCanvas;
        private readonly Border _track;
        private readonly Border _progressFill;
        private readonly Ellipse _sunGlow;
        private readonly Ellipse _sun;
        private readonly TextBlock _startLabel;
        private readonly TextBlock _percentLabel;
        private readonly TextBlock _endLabel;
        private readonly TextBlock _scheduleLabel;
        private readonly TextBlock _hintLabel;
        private readonly DispatcherTimer _timer;
        private readonly ContextMenu _contextMenu;

        private SettingsWindow _settingsWindow;
        private WinForms.NotifyIcon _trayIcon;
        private WinForms.ContextMenuStrip _trayMenu;
        private Drawing.Icon _appIcon;
        private IntPtr _windowHandle;
        private HwndSource _hwndSource;
        private bool _hotkeyRegistered;
        private bool _allowClose;
        private bool _clickThrough;
        private bool _pulsing;
        private double _lastProgress;
        private long _lastRenderedSecond = -1;

        public WidgetWindow(AppSettings settings, string demoState, bool snapshotMode)
        {
            _settings = settings;
            _snapshotMode = snapshotMode;
            _demoMode = !string.IsNullOrEmpty(demoState);
            _demoNow = BuildDemoNow(demoState);

            Width = WidgetWidth;
            Height = WidgetHeight;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ResizeMode = ResizeMode.NoResize;
            ShowInTaskbar = false;
            Topmost = settings.Topmost;
            FontFamily = new FontFamily("Microsoft YaHei UI");
            SnapsToDevicePixels = true;
            UseLayoutRounding = true;

            _root = (Grid)Xaml.Load("OffWorkCountdown.ui.WidgetWindow.xaml");
            _root.Background = Brushes.Transparent;
            Content = _root;

            _glassBack = Find<Border>(_root, "GlassBack");
            _glowLayer = Find<Grid>(_root, "GlowLayer");
            _gearButton = Find<Button>(_root, "GearButton");
            _dateText = Find<TextBlock>(_root, "DateText");
            _modeLabel = Find<TextBlock>(_root, "ModeLabel");
            _timeText = Find<TextBlock>(_root, "TimeText");
            _progressCanvas = Find<Canvas>(_root, "ProgressCanvas");
            _track = Find<Border>(_root, "Track");
            _progressFill = Find<Border>(_root, "ProgressFill");
            _sunGlow = Find<Ellipse>(_root, "SunGlow");
            _sun = Find<Ellipse>(_root, "Sun");
            _startLabel = Find<TextBlock>(_root, "StartLabel");
            _percentLabel = Find<TextBlock>(_root, "PercentLabel");
            _endLabel = Find<TextBlock>(_root, "EndLabel");
            _scheduleLabel = Find<TextBlock>(_root, "ScheduleLabel");
            _hintLabel = Find<TextBlock>(_root, "HintLabel");

            _contextMenu = BuildContextMenu();
            _root.ContextMenu = _contextMenu;

            _gearButton.Click += delegate { OpenSettings(); };
            _root.MouseLeftButtonDown += OnMouseLeftButtonDown;
            _root.MouseEnter += OnMouseEnter;
            _root.MouseLeave += OnMouseLeave;
            _root.SizeChanged += OnRootSizeChanged;
            _progressCanvas.SizeChanged += OnProgressSizeChanged;

            Loaded += OnLoaded;
            Closing += OnClosing;
            Closed += OnClosed;

            _timer = new DispatcherTimer(DispatcherPriority.Render);
            _timer.Interval = TimeSpan.FromMilliseconds(250);
            _timer.Tick += delegate { UpdateUi(false); };
        }

        public double WidgetOpacity
        {
            get { return _settings.Opacity; }
        }

        private static T Find<T>(FrameworkElement root, string name) where T : class
        {
            T value = root.FindName(name) as T;
            if (value == null)
            {
                throw new InvalidOperationException("Missing element in WidgetWindow.xaml: " + name);
            }
            return value;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            PlaceWindow();
            SetGlassOpacity(_settings.Opacity);
            UpdateUi(true);

            if (!_snapshotMode)
            {
                _windowHandle = new WindowInteropHelper(this).Handle;
                _hwndSource = HwndSource.FromHwnd(_windowHandle);
                if (_hwndSource != null)
                {
                    _hwndSource.AddHook(WndProc);
                }
                _hotkeyRegistered = Native.RegisterHotKey(
                    _windowHandle, 1,
                    Native.ModControl | Native.ModAlt | Native.ModNoRepeat,
                    Native.VkD);

                CreateTrayIcon();
                _timer.Start();
            }
        }

        private void PlaceWindow()
        {
            Rect work = SystemParameters.WorkArea;
            if (!_demoMode && !_snapshotMode && _settings.HasPosition)
            {
                Left = _settings.Left;
                Top = _settings.Top;
            }
            else
            {
                Left = work.Right - Width - 24;
                Top = work.Bottom - Height - 24;
            }
            ClampToWorkArea();
        }

        private void ClampToWorkArea()
        {
            Rect work = ScreenGeometry.WorkAreaForWindow(this);
            if (Width >= work.Width)
            {
                Left = work.Left;
            }
            else
            {
                Left = Math.Max(work.Left, Math.Min(Left, work.Right - Width));
            }

            if (Height >= work.Height)
            {
                Top = work.Top;
            }
            else
            {
                Top = Math.Max(work.Top, Math.Min(Top, work.Bottom - Height));
            }
        }

        private void SnapToWorkArea()
        {
            Rect work = ScreenGeometry.WorkAreaForWindow(this);
            const double snap = 26;
            if (Math.Abs(Left - work.Left) < snap) Left = work.Left;
            if (Math.Abs(Left + Width - work.Right) < snap) Left = work.Right - Width;
            if (Math.Abs(Top - work.Top) < snap) Top = work.Top;
            if (Math.Abs(Top + Height - work.Bottom) < snap) Top = work.Bottom - Height;
            ClampToWorkArea();
        }

        private void OnMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (_clickThrough) return;
            if (e.ButtonState != MouseButtonState.Pressed) return;

            try
            {
                DragMove();
            }
            catch (InvalidOperationException)
            {
                return;
            }

            SnapToWorkArea();
            _settings.HasPosition = true;
            _settings.Left = Left;
            _settings.Top = Top;
            if (!_demoMode && !_snapshotMode)
            {
                SettingsStore.Save(_settings);
            }
        }

        private void OnMouseEnter(object sender, MouseEventArgs e)
        {
            _gearButton.Opacity = 1.0;
            _glassBack.BorderBrush = Brush("#4AFFFFFF");
        }

        private void OnMouseLeave(object sender, MouseEventArgs e)
        {
            _gearButton.Opacity = 0.5;
            _glassBack.BorderBrush = Brush("#2BFFFFFF");
        }

        private void OnRootSizeChanged(object sender, SizeChangedEventArgs e)
        {
            double width = _glowLayer.ActualWidth > 0 ? _glowLayer.ActualWidth : e.NewSize.Width;
            double height = _glowLayer.ActualHeight > 0 ? _glowLayer.ActualHeight : e.NewSize.Height;
            _glowLayer.Clip = new RectangleGeometry(new Rect(0, 0, width, height), 24, 24);
        }

        private void OnProgressSizeChanged(object sender, SizeChangedEventArgs e)
        {
            LayoutProgress();
        }

        private void LayoutProgress()
        {
            double width = _progressCanvas.ActualWidth;
            if (width <= 0) return;

            _track.Width = width;
            double fillWidth = width * _lastProgress;
            _progressFill.Width = fillWidth;

            double centerX = Math.Max(5.0, Math.Min(width - 5.0, fillWidth));
            Canvas.SetLeft(_sun, centerX - _sun.Width / 2.0);
            Canvas.SetTop(_sun, 3.5);
            Canvas.SetLeft(_sunGlow, centerX - _sunGlow.Width / 2.0);
            Canvas.SetTop(_sunGlow, -1.5);
        }

        private void UpdateUi(bool force)
        {
            DateTime now = _demoNow.HasValue ? _demoNow.Value : DateTime.Now;
            long secondKey = now.Ticks / TimeSpan.TicksPerSecond;
            if (!force && secondKey == _lastRenderedSecond) return;
            _lastRenderedSecond = secondKey;

            CountdownSnapshot snap = CountdownEngine.Evaluate(
                now, _settings.StartMinutes, _settings.EndMinutes, _settings.WorkdaysOnly);

            _dateText.Text = WeekdayCN(now.DayOfWeek) + " " + now.ToString("MM/dd", CultureInfo.InvariantCulture);
            _startLabel.Text = CountdownEngine.FormatMinutes(snap.StartMinutes) + " 上班";
            _endLabel.Text = CountdownEngine.FormatMinutes(snap.EndMinutes) + " 下班";
            _lastProgress = snap.Progress;

            string accent;
            string timeColor;
            _timeText.FontSize = 40;

            switch (snap.Mode)
            {
                case CountdownMode.BeforeWork:
                    _modeLabel.Text = "距上班";
                    _timeText.Text = CountdownEngine.FormatDuration(snap.Remaining, true);
                    _timeText.Foreground = Brush("#EDF2FA");
                    _timeText.FontSize = 40;
                    _percentLabel.Text = "还没开始";
                    _scheduleLabel.Text = CountdownEngine.FormatMinutes(snap.StartMinutes) + " — " +
                                          CountdownEngine.FormatMinutes(snap.EndMinutes);
                    _hintLabel.Text = "新的一天";
                    accent = "#93A7C2";
                    timeColor = "#EDF2FA";
                    break;

                case CountdownMode.Working:
                    _modeLabel.Text = "距下班";
                    _timeText.Text = CountdownEngine.FormatDuration(snap.Remaining, true);
                    _timeText.Foreground = Brush("#F8F9FB");
                    _timeText.FontSize = 40;
                    _percentLabel.Text = "已过 " + (int)Math.Round(snap.Progress * 100.0) + "%";
                    _scheduleLabel.Text = CountdownEngine.FormatMinutes(snap.StartMinutes) + " — " +
                                          CountdownEngine.FormatMinutes(snap.EndMinutes);
                    _hintLabel.Text = "进行中";
                    accent = "#E9A45F";
                    timeColor = "#F8F9FB";
                    break;

                case CountdownMode.Soon:
                    _modeLabel.Text = "快下班了";
                    _timeText.Text = CountdownEngine.FormatDuration(snap.Remaining, true);
                    _timeText.Foreground = Brush("#FFD1A6");
                    _timeText.FontSize = 40;
                    _percentLabel.Text = "已过 " + (int)Math.Round(snap.Progress * 100.0) + "%";
                    _scheduleLabel.Text = CountdownEngine.FormatMinutes(snap.StartMinutes) + " — " +
                                          CountdownEngine.FormatMinutes(snap.EndMinutes);
                    _hintLabel.Text = "准备收尾";
                    accent = "#FF9E6E";
                    timeColor = "#FFD1A6";
                    break;

                case CountdownMode.Overtime:
                    _modeLabel.Text = "已下班";
                    _timeText.Text = "+" + CountdownEngine.FormatDuration(snap.Remaining, true);
                    _timeText.Foreground = Brush("#82E7C0");
                    _timeText.FontSize = 38;
                    _percentLabel.Text = "今日已完成";
                    _scheduleLabel.Text = CountdownEngine.FormatMinutes(snap.StartMinutes) + " — " +
                                          CountdownEngine.FormatMinutes(snap.EndMinutes);
                    _hintLabel.Text = "今天辛苦了";
                    accent = "#64D8AC";
                    timeColor = "#82E7C0";
                    break;

                default:
                    _modeLabel.Text = "休息日";
                    _timeText.Text = "好好休息";
                    _timeText.Foreground = Brush("#F1F5FB");
                    _timeText.FontSize = 32;
                    _percentLabel.Text = "—";
                    _scheduleLabel.Text = "周一至周五 " +
                                          CountdownEngine.FormatMinutes(snap.StartMinutes) + " — " +
                                          CountdownEngine.FormatMinutes(snap.EndMinutes);
                    _hintLabel.Text = "不用定闹钟";
                    accent = "#7F92AA";
                    timeColor = "#F1F5FB";
                    break;
            }

            _timeText.Foreground = Brush(timeColor);
            _modeLabel.Foreground = Brush(accent);
            _progressFill.Background = ProgressBrush(accent);
            _track.Visibility = snap.Mode == CountdownMode.RestDay ? Visibility.Collapsed : Visibility.Visible;
            _progressFill.Visibility = snap.Mode == CountdownMode.RestDay ? Visibility.Collapsed : Visibility.Visible;
            _sun.Visibility = snap.Mode == CountdownMode.RestDay ? Visibility.Collapsed : Visibility.Visible;
            _sunGlow.Visibility = snap.Mode == CountdownMode.RestDay ? Visibility.Collapsed : Visibility.Visible;
            _sun.Opacity = snap.Mode == CountdownMode.Overtime ? 0.16 : 1.0;
            _sunGlow.Opacity = snap.Mode == CountdownMode.BeforeWork
                ? 0.45
                : snap.Mode == CountdownMode.Overtime ? 0.22 : 1.0;

            SetPulse(snap.Mode == CountdownMode.Soon);
            LayoutProgress();
        }

        private void SetPulse(bool active)
        {
            if (_pulsing == active) return;
            _pulsing = active;
            if (active)
            {
                DoubleAnimation animation = new DoubleAnimation(0.35, 1.0, TimeSpan.FromMilliseconds(820));
                animation.AutoReverse = true;
                animation.RepeatBehavior = RepeatBehavior.Forever;
                animation.EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut };
                _sunGlow.BeginAnimation(OpacityProperty, animation);
            }
            else
            {
                _sunGlow.BeginAnimation(OpacityProperty, null);
            }
        }

        public void SetGlassOpacity(double value)
        {
            if (value < 0.65) value = 0.65;
            if (value > 1.0) value = 1.0;
            _glassBack.Opacity = value;
        }

        public void PreviewGlassOpacity(double value)
        {
            SetGlassOpacity(value);
        }

        public void ApplySettings(AppSettings next)
        {
            _settings.CopyFrom(next);
            _settings.Normalize();
            Topmost = _settings.Topmost;
            SetGlassOpacity(_settings.Opacity);
            if (!_demoMode && !_snapshotMode)
            {
                SettingsStore.Save(_settings);
            }
            UpdateUi(true);
        }

        private void OpenSettings()
        {
            if (_clickThrough) return;
            if (_settingsWindow != null)
            {
                _settingsWindow.Activate();
                return;
            }

            _settingsWindow = new SettingsWindow(_settings, this);
            _settingsWindow.Owner = this;
            _settingsWindow.Closed += delegate { _settingsWindow = null; };
            _settingsWindow.Show();
        }

        private ContextMenu BuildContextMenu()
        {
            ContextMenu menu = new ContextMenu();

            MenuItem settings = new MenuItem();
            settings.Header = "设置…";
            settings.Click += delegate { OpenSettings(); };

            MenuItem topmost = new MenuItem();
            topmost.Click += delegate { ToggleTopmost(); };

            MenuItem clickThrough = new MenuItem();
            clickThrough.Click += delegate { ToggleClickThrough(); };

            MenuItem hide = new MenuItem();
            hide.Header = "隐藏到托盘";
            hide.Click += delegate { HideToTray(); };

            MenuItem exit = new MenuItem();
            exit.Header = "退出";
            exit.Click += delegate { ExitApp(); };

            menu.Items.Add(settings);
            menu.Items.Add(topmost);
            menu.Items.Add(clickThrough);
            menu.Items.Add(new Separator());
            menu.Items.Add(hide);
            menu.Items.Add(exit);

            menu.Opened += delegate
            {
                topmost.Header = "窗口置顶：" + (Topmost ? "开" : "关");
                clickThrough.Header = "鼠标穿透：" + (_clickThrough ? "开" : "关");
                settings.IsEnabled = !_clickThrough;
                hide.IsEnabled = !_snapshotMode;
            };

            return menu;
        }

        private void ToggleTopmost()
        {
            Topmost = !Topmost;
            _settings.Topmost = Topmost;
            if (!_demoMode && !_snapshotMode)
            {
                SettingsStore.Save(_settings);
            }
            if (_settingsWindow != null)
            {
                _settingsWindow.Topmost = true;
            }
        }

        private void ToggleClickThrough()
        {
            if (_settingsWindow != null)
            {
                _settingsWindow.Close();
            }

            _clickThrough = !_clickThrough;
            WindowInteropHelper helper = new WindowInteropHelper(this);
            Native.SetClickThrough(helper.Handle, _clickThrough);

            if (_clickThrough && _trayIcon != null)
            {
                try
                {
                    string how = _hotkeyRegistered
                        ? "按 Ctrl+Alt+D，或右键任务栏托盘里的日落图标。"
                        : "右键任务栏托盘里的日落图标即可关掉。";
                    _trayIcon.ShowBalloonTip(3000, "鼠标穿透已开启",
                        how, WinForms.ToolTipIcon.None);
                }
                catch (Exception)
                {
                    // Notifications can be disabled by policy; the tray menu still works.
                }
            }
        }

        private void CreateTrayIcon()
        {
            _appIcon = LoadAppIcon();
            _trayIcon = new WinForms.NotifyIcon();
            _trayIcon.Icon = _appIcon;
            _trayIcon.Text = "下班倒计时";
            _trayIcon.Visible = true;
            _trayIcon.DoubleClick += delegate { OnUi(ShowWidget); };

            _trayMenu = new WinForms.ContextMenuStrip();
            _trayMenu.ShowImageMargin = false;
            _trayMenu.ShowItemToolTips = true;

            WinForms.ToolStripMenuItem show = new WinForms.ToolStripMenuItem("隐藏小窗");
            show.Click += delegate { OnUi(delegate { if (IsVisible) HideToTray(); else ShowWidget(); }); };

            WinForms.ToolStripMenuItem settings = new WinForms.ToolStripMenuItem("设置…");
            settings.Click += delegate
            {
                OnUi(delegate
                {
                    if (_clickThrough) ToggleClickThrough();
                    ShowWidget();
                    OpenSettings();
                });
            };

            WinForms.ToolStripMenuItem topmost = new WinForms.ToolStripMenuItem("窗口置顶");
            topmost.CheckOnClick = true;
            topmost.Checked = Topmost;
            topmost.Click += delegate { OnUi(delegate { if (Topmost != topmost.Checked) ToggleTopmost(); }); };

            WinForms.ToolStripMenuItem clickThrough = new WinForms.ToolStripMenuItem("鼠标穿透");
            clickThrough.CheckOnClick = true;
            clickThrough.ToolTipText = _hotkeyRegistered
                ? "快捷键 Ctrl+Alt+D"
                : "点击关闭鼠标穿透";
            clickThrough.Click += delegate { OnUi(ToggleClickThrough); };

            WinForms.ToolStripMenuItem exit = new WinForms.ToolStripMenuItem("退出");
            exit.Click += delegate { OnUi(ExitApp); };

            _trayMenu.Items.Add(show);
            _trayMenu.Items.Add(settings);
            _trayMenu.Items.Add(new WinForms.ToolStripSeparator());
            _trayMenu.Items.Add(topmost);
            _trayMenu.Items.Add(clickThrough);
            _trayMenu.Items.Add(new WinForms.ToolStripSeparator());
            _trayMenu.Items.Add(exit);

            _trayMenu.Opening += delegate
            {
                show.Text = IsVisible ? "隐藏小窗" : "显示小窗";
                show.Checked = false;
                topmost.Checked = Topmost;
                clickThrough.Checked = _clickThrough;
            };

            _trayIcon.ContextMenuStrip = _trayMenu;
        }

        private Drawing.Icon LoadAppIcon()
        {
            try
            {
                using (Stream stream = Assembly.GetExecutingAssembly()
                    .GetManifestResourceStream(IconResource))
                {
                    if (stream != null)
                    {
                        return new Drawing.Icon(stream);
                    }
                }
            }
            catch (Exception)
            {
                // Fall through to the stock icon; never block the widget for an icon.
            }
            return Drawing.SystemIcons.Application;
        }

        private void OnUi(Action action)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.BeginInvoke(action);
                return;
            }
            action();
        }

        public void ShowFromSecondInstance()
        {
            ShowWidget();
        }

        private void ShowWidget()
        {
            if (!IsVisible) Show();
            if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
            Topmost = true;
            Topmost = _settings.Topmost;
            Activate();
        }

        private void HideToTray()
        {
            if (_settingsWindow != null)
            {
                _settingsWindow.Close();
            }
            Hide();
            if (_trayIcon != null && !_snapshotMode)
            {
                try
                {
                    _trayIcon.ShowBalloonTip(1800, "下班倒计时",
                        "小窗已收到托盘，双击日落图标就能叫回来。",
                        WinForms.ToolTipIcon.None);
                }
                catch (Exception)
                {
                    // Balloon tips are best-effort only.
                }
            }
        }

        private void ExitApp()
        {
            _allowClose = true;
            _timer.Stop();
            if (_trayIcon != null)
            {
                _trayIcon.Visible = false;
                _trayIcon.Dispose();
                _trayIcon = null;
            }
            Application.Current.Shutdown();
        }

        private void OnClosing(object sender, CancelEventArgs e)
        {
            if (_allowClose || _snapshotMode) return;
            e.Cancel = true;
            HideToTray();
        }

        private void OnClosed(object sender, EventArgs e)
        {
            _timer.Stop();
            if (_hwndSource != null)
            {
                _hwndSource.RemoveHook(WndProc);
                _hwndSource = null;
            }
            if (_hotkeyRegistered && _windowHandle != IntPtr.Zero)
            {
                Native.UnregisterHotKey(_windowHandle, 1);
                _hotkeyRegistered = false;
            }
            if (_trayIcon != null)
            {
                _trayIcon.Visible = false;
                _trayIcon.Dispose();
                _trayIcon = null;
            }
        }

        private IntPtr WndProc(IntPtr hwnd, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            const int WmHotkey = 0x0312;
            const int WmNcHitTest = 0x0084;

            if (message == WmHotkey && wParam.ToInt32() == 1)
            {
                ToggleClickThrough();
                handled = true;
                return IntPtr.Zero;
            }

            // The window rectangle includes a transparent halo for the drop
            // shadow. Let clicks in that halo fall through to the desktop so
            // the widget does not steal a ring of invisible clicks.
            if (message == WmNcHitTest && !_clickThrough && _glassBack.IsVisible)
            {
                int packed = lParam.ToInt32();
                int screenX = (short)(packed & 0xFFFF);
                int screenY = (short)((packed >> 16) & 0xFFFF);
                Point topLeft = _glassBack.PointToScreen(new Point(0, 0));
                Point bottomRight = _glassBack.PointToScreen(
                    new Point(_glassBack.ActualWidth, _glassBack.ActualHeight));

                bool inside = screenX >= topLeft.X && screenX < bottomRight.X &&
                              screenY >= topLeft.Y && screenY < bottomRight.Y;
                if (!inside)
                {
                    handled = true;
                    return new IntPtr(-1); // HTTRANSPARENT
                }
            }

            return IntPtr.Zero;
        }

        public void CloseForSnapshot()
        {
            _allowClose = true;
            _timer.Stop();
            Close();
        }

        public void SaveSnapshot(string path)
        {
            _root.UpdateLayout();
            int pixelWidth = (int)Math.Ceiling(Width * 2.0);
            int pixelHeight = (int)Math.Ceiling(Height * 2.0);
            if (pixelWidth <= 0 || pixelHeight <= 0) return;

            RenderTargetBitmap bitmap = new RenderTargetBitmap(
                pixelWidth, pixelHeight, 192, 192, PixelFormats.Pbgra32);
            bitmap.Render(this);

            PngBitmapEncoder encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));

            string fullPath = Path.GetFullPath(path);
            string folder = Path.GetDirectoryName(fullPath);
            if (!string.IsNullOrEmpty(folder)) Directory.CreateDirectory(folder);
            using (FileStream stream = File.Create(fullPath))
            {
                encoder.Save(stream);
            }
        }

        private static DateTime? BuildDemoNow(string state)
        {
            if (string.IsNullOrEmpty(state)) return null;

            DateTime workday = DateTime.Today;
            while (workday.DayOfWeek == DayOfWeek.Saturday || workday.DayOfWeek == DayOfWeek.Sunday)
            {
                workday = workday.AddDays(1);
            }

            switch (state.ToLowerInvariant())
            {
                case "before":
                    return workday.AddHours(8).AddMinutes(12).AddSeconds(18);
                case "working":
                    return workday.AddHours(14).AddMinutes(32).AddSeconds(18);
                case "soon":
                    return workday.AddHours(17).AddMinutes(52).AddSeconds(8);
                case "over":
                    return workday.AddHours(18).AddMinutes(42).AddSeconds(26);
                case "rest":
                    DateTime day = DateTime.Today;
                    while (day.DayOfWeek != DayOfWeek.Saturday) day = day.AddDays(1);
                    return day.AddHours(11).AddMinutes(10).AddSeconds(24);
                default:
                    return DateTime.Now;
            }
        }

        private static string WeekdayCN(DayOfWeek day)
        {
            switch (day)
            {
                case DayOfWeek.Monday: return "周一";
                case DayOfWeek.Tuesday: return "周二";
                case DayOfWeek.Wednesday: return "周三";
                case DayOfWeek.Thursday: return "周四";
                case DayOfWeek.Friday: return "周五";
                case DayOfWeek.Saturday: return "周六";
                default: return "周日";
            }
        }

        private static Color Hex(string value)
        {
            return (Color)ColorConverter.ConvertFromString(value);
        }

        private static SolidColorBrush Brush(string value)
        {
            SolidColorBrush brush = new SolidColorBrush(Hex(value));
            brush.Freeze();
            return brush;
        }

        private static LinearGradientBrush ProgressBrush(string value)
        {
            Color color = Hex(value);
            LinearGradientBrush brush = new LinearGradientBrush();
            brush.StartPoint = new Point(0, 0);
            brush.EndPoint = new Point(1, 0);
            brush.GradientStops.Add(new GradientStop(Color.FromArgb(190, color.R, color.G, color.B), 0));
            brush.GradientStops.Add(new GradientStop(Color.FromArgb(255,
                (byte)Math.Min(255, color.R + 24),
                (byte)Math.Min(255, color.G + 20),
                (byte)Math.Min(255, color.B + 18)), 0.55));
            brush.GradientStops.Add(new GradientStop(color, 1));
            brush.Freeze();
            return brush;
        }
    }
}
