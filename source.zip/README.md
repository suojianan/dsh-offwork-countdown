# 下班倒计时 · 桌面悬浮小窗

一个常驻 Windows 桌面的半透明下班倒计时。无边框、始终置顶、可拖动，带托盘图标和设置面板。

双击 `OffWorkCountdown.exe` 即可运行，不需要安装运行时（Windows 10/11 自带 .NET Framework 4.8）。

![下班倒计时预览](preview/working.png)

## 它做什么

- **距下班倒计时**：按上班 / 下班时间实时计算，显示 `HH:MM:SS`。
- **日落入海进度**：一条横线代表今天的工作区间，太阳从上班滑到下班；过了下班时间，太阳沉到线的尽头。
- **状态跟随时间变化**：
  - 上班前：`距上班`，冷色；
  - 工作中：`距下班`，暖色；
  - 最后 10 分钟：`快下班了`，数字变暖、太阳轻微呼吸；
  - 下班后：`已下班 +HH:MM:SS`，薄荷绿，继续记录加班；
  - 周末：`休息日`，收起进度。
- **半透明**：默认 88% 不透明度，能看到背后的桌面；设置里可以在 65%–100% 之间调。
- **悬浮**：始终置顶、可拖到任意位置，松手后靠近屏幕边缘会自动贴边，下次启动回到上次位置。
- **托盘**：隐藏到托盘、显示、设置、置顶、鼠标穿透、退出。
- **鼠标穿透**：开启后小窗不挡鼠标，方便盖在别的窗口上；按 `Ctrl+Alt+D` 或右键托盘图标可以关掉。
- **单实例**：再次双击 exe 不会开第二个小窗，只会把已有的叫到前面。
- **设置持久化**：上班/下班时间、是否仅工作日、不透明度、置顶、位置都会记住。

## 操作

| 操作 | 效果 |
| --- | --- |
| 按住小窗拖动 | 移动位置，松手贴边 |
| 点右上角齿轮 | 打开设置 |
| 右键小窗 | 设置 / 置顶 / 鼠标穿透 / 隐藏 / 退出 |
| 双击托盘图标 | 显示小窗 |
| 右键托盘图标 | 完整菜单 |
| `Ctrl+Alt+D` | 开关鼠标穿透 |

设置里的「恢复默认」会把时间恢复为 **09:00 – 18:00**、仅工作日、88% 不透明度、置顶。

![五种状态](preview/states.png)

![设置面板](preview/settings.png)

## 系统要求

- 64 位 Windows 10 1909 及以上 / Windows 11
- .NET Framework 4.8（Windows 10 2004+ 和 Windows 11 自带；老系统装一次即可）
- 已声明 Per-Monitor V2 DPI 感知，高分屏下由 WPF 缩放；混合 DPI 多屏下贴边可能有一两像素偏差
- 不支持跨午夜班次：下班时间必须晚于上班时间
- 休息日只按周六 / 周日判断，不识别法定节假日

如果桌面壁纸特别亮，半透明下的次要文字会变得清淡；把小窗调高不透明度（设置里的滑块）即可。

## 配置

设置保存在：

```
%APPDATA%\OffWorkCountdown\settings.json
```

开发 / 便携模式可以设置环境变量 `OWC_DATA_DIR` 指向另一个目录，设置和日志都会写到那里。

## 开发

源码是纯 C# + WPF，没有 NuGet 依赖，单个 `.exe`：

```
src/
  Program.cs           入口、单实例、快照模式
  WidgetWindow.cs      主小窗：计时、拖动、托盘、右键菜单、鼠标穿透
  SettingsWindow.cs    设置面板
  CountdownEngine.cs   纯时间计算（有独立测试）
  AppSettings.cs       设置读写（JSON）
  ScreenGeometry.cs    当前显示器工作区（贴边避开任务栏）
  Native.cs            Win32：鼠标穿透、全局热键
  Xaml.cs              从嵌入资源加载界面
app.manifest            Per-Monitor V2 DPI 声明
ui/
  Theme.xaml           按钮、输入框、开关、滑杆、菜单样式
  WidgetWindow.xaml    主小窗布局
  SettingsWindow.xaml  设置面板布局
assets/
  icon.ico / icon.png  应用与托盘图标
  make_icon.py         图标生成脚本（Pillow）
  make_showcase.py     展示图合成脚本（Pillow）
  make_states.py       五种状态拼图脚本（Pillow）
tests/
  EngineTests.cs       29 项时间状态测试
```

### 构建

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\build.ps1
```

构建依赖 Windows 自带的 `csc.exe`（.NET Framework 4.8），不需要 .NET SDK。生成 `OffWorkCountdown.exe`，界面 XAML、清单和图标都嵌入 exe。构建前如果小窗正在运行，脚本会提示先从托盘退出（运行中的 exe 会被写锁）。

### 测试

```powershell
.\run-tests.ps1
```

只测时间逻辑（状态、边界、格式化、解析）。UI 与托盘行为需要在本机实际运行检查。

### 预览快照

exe 内置了开发用的状态快照，不会出现在正常使用中：

```powershell
.\OffWorkCountdown.exe --demo soon --snapshot preview\soon.png
```

`--demo` 可取 `before` / `working` / `soon` / `over` / `rest`。快照是透明 PNG，方便放到展示图里。

## 设计笔记

- 主色是落日暖橙，不是常见的蓝紫渐变；加班用薄荷绿，休息用冷灰蓝。
- 一屏只有一个焦点：大号等宽倒计时。其余信息按 12 / 11 / 10.5 / 10 的字号阶梯退后。
- 进度线是一段「地平线」：太阳的位置就是今天的进度，比普通进度条更像这个产品自己的东西。
- 玻璃层和文字层分开：调不透明度只影响背景，不影响文字清晰度。
- 小窗没有标题栏，所有操作都在齿轮、右键和托盘里，不占桌面空间。

## 已知取舍

- 不支持跨午夜班次，设置会拒绝「下班时间早于上班时间」。
- 托盘图标默认可能收在 Windows 的「^」溢出区里，可以拖到任务栏常驻。
- 多屏可以拖动；贴边吸附按当前显示器的工作区计算，不会被任务栏挡住。
