"""Compose a desktop-like showcase image around the transparent widget capture."""

from __future__ import annotations

import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "preview" / "showcase.png"
WIDGET = ROOT / "preview" / "working.png"

W, H = 1600, 1000


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def mix(c1, c2, t):
    return tuple(int(round(lerp(c1[i], c2[i], t))) for i in range(3))


def gradient(top, bottom):
    image = Image.new("RGB", (1, H))
    px = image.load()
    for y in range(H):
        t = y / (H - 1)
        # ease into the warm horizon a little faster than a straight ramp
        tt = t ** 1.35
        px[0, y] = mix(top, bottom, tt)
    return image.resize((W, H), Image.Resampling.BICUBIC)


def radial_glow(size, color, alpha):
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    px = image.load()
    c = (size - 1) / 2
    for y in range(size):
        for x in range(size):
            d = math.hypot(x - c, y - c) / c
            if d >= 1:
                continue
            a = int(alpha * (1 - d) ** 2.1)
            px[x, y] = (color[0], color[1], color[2], a)
    return image


def mountain(draw, base_y, color, peaks, blur=0):
    points = [(-50, H + 50)]
    for x, y in peaks:
        points.append((x, y))
    points.append((W + 50, H + 50))
    draw.polygon(points, fill=color)
    return points


def build():
    sky = gradient((11, 18, 31), (61, 42, 40)).convert("RGBA")
    canvas = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    canvas.alpha_composite(sky)

    # Low sun haze behind the hills.
    glow = radial_glow(760, (244, 150, 92), 115)
    glow = glow.filter(ImageFilter.GaussianBlur(60))
    canvas.alpha_composite(glow, (W - 760 - 20, H - 760 + 120))
    core = radial_glow(300, (255, 190, 126), 210)
    core = core.filter(ImageFilter.GaussianBlur(28))
    canvas.alpha_composite(core, (W - 300 - 250, H - 300 - 20))

    # Two layers of hills.
    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw = ImageDraw.Draw(layer)
    mountains = [
        (-60, 790), (120, 690), (250, 735), (410, 640), (560, 720),
        (710, 645), (860, 730), (1010, 665), (1180, 745), (1330, 690),
        (1480, 745), (1660, 700),
    ]
    draw.polygon([(-80, H + 80)] + mountains + [(W + 80, H + 80)],
                 fill=(12, 22, 30, 255))
    layer = layer.filter(ImageFilter.GaussianBlur(10))
    canvas.alpha_composite(layer)

    layer2 = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    draw2 = ImageDraw.Draw(layer2)
    mountains2 = [
        (-40, 880), (170, 810), (330, 860), (500, 785), (690, 850),
        (860, 790), (1040, 865), (1210, 805), (1390, 860), (1550, 820),
        (1660, 850),
    ]
    draw2.polygon([(-80, H + 80)] + mountains2 + [(W + 80, H + 80)],
                  fill=(8, 14, 20, 255))
    layer2 = layer2.filter(ImageFilter.GaussianBlur(14))
    canvas.alpha_composite(layer2)

    # A quiet reflection strip of light on the valley floor.
    strip = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(strip)
    sd.rectangle((0, 900, W, 1000), fill=(30, 44, 44, 100))
    strip = strip.filter(ImageFilter.GaussianBlur(40))
    canvas.alpha_composite(strip)

    # Film grain.
    random.seed(11)
    noise = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    npx = noise.load()
    for _ in range(28000):
        x = random.randrange(W)
        y = random.randrange(H)
        value = random.choice((255, 0))
        npx[x, y] = (value, value, value, random.randrange(4, 10))
    noise = noise.filter(ImageFilter.GaussianBlur(0.4))
    canvas.alpha_composite(noise)

    # The widget capture is transparent; resize it to a comfortable desktop
    # scale and let its own shadow land on the scene.
    widget = Image.open(WIDGET).convert("RGBA")
    target_w = 552
    target_h = round(widget.height * target_w / widget.width)
    widget = widget.resize((target_w, target_h), Image.Resampling.LANCZOS)
    x = W - target_w - 70
    y = H - target_h - 54
    canvas.alpha_composite(widget, (x, y))

    canvas.convert("RGB").save(OUT, format="PNG", quality=94)
    print(f"wrote {OUT}")


if __name__ == "__main__":
    build()
