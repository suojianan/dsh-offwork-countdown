using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("下班倒计时")]
[assembly: AssemblyDescription("半透明桌面下班倒计时小窗")]
[assembly: AssemblyProduct("OffWorkCountdown")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
