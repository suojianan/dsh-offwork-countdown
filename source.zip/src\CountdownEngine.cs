using System;
using System.Globalization;

namespace OffWorkCountdown
{
    public enum CountdownMode
    {
        BeforeWork,
        Working,
        Soon,
        Overtime,
        RestDay
    }

    public sealed class CountdownSnapshot
    {
        public CountdownMode Mode { get; set; }
        public TimeSpan Remaining { get; set; }
        public double Progress { get; set; }
        public DateTime Now { get; set; }
        public int StartMinutes { get; set; }
        public int EndMinutes { get; set; }
    }

    /// <summary>
    /// Pure clock logic, deliberately free of WPF types so it can be exercised
    /// by the console test harness without a desktop session.
    /// </summary>
    public static class CountdownEngine
    {
        public const int SoonThresholdSeconds = 10 * 60;

        public static CountdownSnapshot Evaluate(DateTime now, int startMinutes, int endMinutes, bool workdaysOnly)
        {
            if (startMinutes < 0) startMinutes = 0;
            if (startMinutes > 1439) startMinutes = 1439;
            if (endMinutes <= startMinutes) endMinutes = Math.Min(1439, startMinutes + 1);
            if (endMinutes > 1440) endMinutes = 1440;

            double nowSeconds = now.TimeOfDay.TotalSeconds;
            double startSeconds = startMinutes * 60.0;
            double endSeconds = endMinutes * 60.0;

            CountdownSnapshot snapshot = new CountdownSnapshot();
            snapshot.Now = now;
            snapshot.StartMinutes = startMinutes;
            snapshot.EndMinutes = endMinutes;

            bool weekend = now.DayOfWeek == DayOfWeek.Saturday || now.DayOfWeek == DayOfWeek.Sunday;
            if (workdaysOnly && weekend)
            {
                snapshot.Mode = CountdownMode.RestDay;
                snapshot.Remaining = TimeSpan.Zero;
                snapshot.Progress = 0.0;
                return snapshot;
            }

            if (nowSeconds < startSeconds)
            {
                snapshot.Mode = CountdownMode.BeforeWork;
                snapshot.Remaining = SecondsToRemaining(startSeconds - nowSeconds);
                snapshot.Progress = 0.0;
                return snapshot;
            }

            if (nowSeconds < endSeconds)
            {
                double remaining = endSeconds - nowSeconds;
                snapshot.Mode = remaining <= SoonThresholdSeconds
                    ? CountdownMode.Soon
                    : CountdownMode.Working;
                snapshot.Remaining = SecondsToRemaining(remaining);
                snapshot.Progress = Clamp01((nowSeconds - startSeconds) / (endSeconds - startSeconds));
                return snapshot;
            }

            snapshot.Mode = CountdownMode.Overtime;
            snapshot.Remaining = SecondsToRemaining(nowSeconds - endSeconds);
            snapshot.Progress = 1.0;
            return snapshot;
        }

        public static string FormatDuration(TimeSpan value, bool alwaysShowHours)
        {
            long total = (long)Math.Floor(value.TotalSeconds);
            if (total < 0) total = 0;
            long hours = total / 3600;
            long minutes = (total % 3600) / 60;
            long seconds = total % 60;
            if (alwaysShowHours || hours > 0)
            {
                return string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}:{2:00}",
                    hours, minutes, seconds);
            }
            return string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}", minutes, seconds);
        }

        public static string FormatMinutes(int minutes)
        {
            if (minutes < 0) minutes = 0;
            if (minutes > 1439) minutes = 1439;
            return string.Format(CultureInfo.InvariantCulture, "{0:00}:{1:00}",
                minutes / 60, minutes % 60);
        }

        public static bool TryParseMinutes(string text, out int minutes)
        {
            minutes = 0;
            if (string.IsNullOrEmpty(text)) return false;
            string cleaned = text.Trim().Replace('：', ':');
            string[] parts = cleaned.Split(':');
            if (parts.Length != 2) return false;

            int hours;
            int mins;
            if (!int.TryParse(parts[0], NumberStyles.Integer, CultureInfo.InvariantCulture, out hours)) return false;
            if (!int.TryParse(parts[1], NumberStyles.Integer, CultureInfo.InvariantCulture, out mins)) return false;
            if (hours < 0 || hours > 23 || mins < 0 || mins > 59) return false;

            minutes = hours * 60 + mins;
            return true;
        }

        public static double Clamp01(double value)
        {
            if (value < 0.0) return 0.0;
            if (value > 1.0) return 1.0;
            return value;
        }

        private static TimeSpan SecondsToRemaining(double seconds)
        {
            if (seconds < 0.0) seconds = 0.0;
            return TimeSpan.FromSeconds(Math.Ceiling(seconds));
        }
    }
}
