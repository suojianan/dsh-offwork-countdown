using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace OffWorkCountdown
{
    public sealed class AppSettings
    {
        public const int DefaultStartMinutes = 9 * 60;
        public const int DefaultEndMinutes = 18 * 60;
        public const double DefaultOpacity = 0.88;

        public int StartMinutes { get; set; }
        public int EndMinutes { get; set; }
        public bool WorkdaysOnly { get; set; }
        public double Opacity { get; set; }
        public bool Topmost { get; set; }
        public bool HasPosition { get; set; }
        public double Left { get; set; }
        public double Top { get; set; }

        public AppSettings()
        {
            ResetToDefaults();
        }

        public void ResetToDefaults()
        {
            StartMinutes = DefaultStartMinutes;
            EndMinutes = DefaultEndMinutes;
            WorkdaysOnly = true;
            Opacity = DefaultOpacity;
            Topmost = true;
            HasPosition = false;
            Left = 0;
            Top = 0;
        }

        public AppSettings Clone()
        {
            AppSettings copy = new AppSettings();
            copy.StartMinutes = StartMinutes;
            copy.EndMinutes = EndMinutes;
            copy.WorkdaysOnly = WorkdaysOnly;
            copy.Opacity = Opacity;
            copy.Topmost = Topmost;
            copy.HasPosition = HasPosition;
            copy.Left = Left;
            copy.Top = Top;
            return copy;
        }

        public void CopyFrom(AppSettings other)
        {
            if (other == null) return;
            StartMinutes = other.StartMinutes;
            EndMinutes = other.EndMinutes;
            WorkdaysOnly = other.WorkdaysOnly;
            Opacity = other.Opacity;
            Topmost = other.Topmost;
            HasPosition = other.HasPosition;
            Left = other.Left;
            Top = other.Top;
        }

        public void Normalize()
        {
            if (StartMinutes < 0 || StartMinutes > 1439) StartMinutes = DefaultStartMinutes;
            if (EndMinutes < 1 || EndMinutes > 1439) EndMinutes = DefaultEndMinutes;
            if (EndMinutes <= StartMinutes)
            {
                StartMinutes = DefaultStartMinutes;
                EndMinutes = DefaultEndMinutes;
            }
            if (Opacity < 0.65) Opacity = 0.65;
            if (Opacity > 1.0) Opacity = 1.0;
        }

    }

    public static class SettingsStore
    {
        private const string FileName = "settings.json";

        public static string DirectoryPath
        {
            get
            {
                string custom = Environment.GetEnvironmentVariable("OWC_DATA_DIR");
                if (!string.IsNullOrEmpty(custom))
                {
                    return Path.GetFullPath(custom);
                }
                return Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                    "OffWorkCountdown");
            }
        }

        public static string FilePath
        {
            get { return Path.Combine(DirectoryPath, FileName); }
        }

        public static AppSettings Load()
        {
            AppSettings settings = new AppSettings();
            try
            {
                if (!File.Exists(FilePath))
                {
                    return settings;
                }

                string json = File.ReadAllText(FilePath, Encoding.UTF8);

                string start = ReadString(json, "start");
                string end = ReadString(json, "end");
                int parsed;
                if (CountdownEngine.TryParseMinutes(start, out parsed)) settings.StartMinutes = parsed;
                if (CountdownEngine.TryParseMinutes(end, out parsed)) settings.EndMinutes = parsed;

                bool boolValue;
                if (TryReadBool(json, "workdaysOnly", out boolValue)) settings.WorkdaysOnly = boolValue;
                if (TryReadBool(json, "topmost", out boolValue)) settings.Topmost = boolValue;

                double number;
                if (TryReadDouble(json, "opacity", out number)) settings.Opacity = number;
                if (TryReadDouble(json, "left", out number))
                {
                    settings.Left = number;
                    if (TryReadDouble(json, "top", out number))
                    {
                        settings.Top = number;
                        settings.HasPosition = true;
                    }
                }
            }
            catch (Exception)
            {
                // A damaged settings file should never stop the widget. Defaults win.
            }

            settings.Normalize();
            return settings;
        }

        public static void Save(AppSettings settings)
        {
            if (settings == null) return;
            settings.Normalize();
            try
            {
                Directory.CreateDirectory(DirectoryPath);
                StringBuilder json = new StringBuilder();
                json.AppendLine("{");
                json.AppendLine("  \"version\": 1,");
                json.AppendLine("  \"start\": \"" + CountdownEngine.FormatMinutes(settings.StartMinutes) + "\",");
                json.AppendLine("  \"end\": \"" + CountdownEngine.FormatMinutes(settings.EndMinutes) + "\",");
                json.AppendLine("  \"workdaysOnly\": " + (settings.WorkdaysOnly ? "true" : "false") + ",");
                json.AppendLine("  \"opacity\": " + settings.Opacity.ToString("0.00", CultureInfo.InvariantCulture) + ",");
                json.AppendLine("  \"topmost\": " + (settings.Topmost ? "true" : "false") + ",");
                if (settings.HasPosition)
                {
                    json.AppendLine("  \"left\": " + settings.Left.ToString("0.##", CultureInfo.InvariantCulture) + ",");
                    json.AppendLine("  \"top\": " + settings.Top.ToString("0.##", CultureInfo.InvariantCulture));
                }
                else
                {
                    json.AppendLine("  \"left\": null,");
                    json.AppendLine("  \"top\": null");
                }
                json.AppendLine("}");
                File.WriteAllText(FilePath, json.ToString(), new UTF8Encoding(false));
            }
            catch (Exception)
            {
                // Persistence is a convenience; a locked profile folder is not fatal.
            }
        }

        private static string ReadString(string json, string key)
        {
            Match match = Regex.Match(
                json,
                "\"" + Regex.Escape(key) + "\"\\s*:\\s*\"([^\"]*)\"",
                RegexOptions.IgnoreCase);
            return match.Success ? match.Groups[1].Value : null;
        }

        private static bool TryReadBool(string json, string key, out bool value)
        {
            value = false;
            Match match = Regex.Match(
                json,
                "\"" + Regex.Escape(key) + "\"\\s*:\\s*(true|false)",
                RegexOptions.IgnoreCase);
            if (!match.Success) return false;
            value = string.Equals(match.Groups[1].Value, "true", StringComparison.OrdinalIgnoreCase);
            return true;
        }

        private static bool TryReadDouble(string json, string key, out double value)
        {
            value = 0;
            Match match = Regex.Match(
                json,
                "\"" + Regex.Escape(key) + "\"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?)",
                RegexOptions.IgnoreCase);
            if (!match.Success) return false;
            return double.TryParse(match.Groups[1].Value, NumberStyles.Float,
                CultureInfo.InvariantCulture, out value);
        }
    }
}
