$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$out = Join-Path $root "tests\EngineTests.exe"

& $csc /nologo /target:exe /codepage:65001 /utf8output "/out:$out" `
    (Join-Path $root "src\CountdownEngine.cs") `
    (Join-Path $root "tests\EngineTests.cs")
if ($LASTEXITCODE -ne 0) {
    throw "Test compilation failed with exit code $LASTEXITCODE"
}

& $out
if ($LASTEXITCODE -ne 0) {
    throw "Tests failed with exit code $LASTEXITCODE"
}
