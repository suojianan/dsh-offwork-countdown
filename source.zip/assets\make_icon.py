"""Generate the OffWork Countdown app icon.

Draws a deep-ink rounded tile with a warm setting sun over a horizon line,
then exports a multi-size .ico for the Windows executable and tray.
"""

from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

SCALE = 4
SIZE = 256
S = SIZE * SCALE
OUT = Path(__file__).resolve().parent


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def mix(c1: tuple[int, int, int], c2: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(int(round(lerp(c1[i], c2[i], t))) for i in range(3))


def vertical_gradient(size: tuple[int, int], top: tuple[int, int, int], bottom: tuple[int, int, int]) -> Image.Image:
    width, height = size
    image = Image.new("RGB", (1, height))
    pixels = image.load()
    for y in range(height):
        pixels[0, y] = mix(top, bottom, y / max(1, height - 1))
    return image.resize((width, height), Image.Resampling.BICUBIC)


def radial_glow(size: int, color: tuple[int, int, int], max_alpha: int) -> Image.Image:
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    pixels = image.load()
    center = (size - 1) / 2
    for y in range(size):
        for x in range(size):
            distance = math.hypot(x - center, y - center) / center
            if distance >= 1:
                continue
            alpha = int(round(max_alpha * (1 - distance) ** 2.2))
            pixels[x, y] = (color[0], color[1], color[2], alpha)
    return image


def rounded_mask(size: int, radius: int) -> Image.Image:
    mask = Image.new("L", (size, size), 0)
    draw = ImageDraw.Draw(mask)
    draw.rounded_rectangle((0, 0, size - 1, size - 1), radius=radius, fill=255)
    return mask


def build() -> Image.Image:
    canvas = Image.new("RGBA", (S, S), (0, 0, 0, 0))

    # Body: deep ink glass tile.
    body = vertical_gradient((S, S), (26, 31, 43), (9, 11, 16)).convert("RGBA")
    body.putalpha(rounded_mask(S, int(56 * SCALE)))
    canvas.alpha_composite(body)

    # A soft warm bloom rising from the lower right, like late afternoon light.
    bloom = radial_glow(int(S * 0.95), (240, 146, 78), 118)
    bloom = bloom.filter(ImageFilter.GaussianBlur(int(22 * SCALE)))
    canvas.alpha_composite(bloom, (int(S * 0.10), int(S * 0.22)))

    # Fine inner rim.
    rim = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    rim_draw = ImageDraw.Draw(rim)
    rim_draw.rounded_rectangle(
        (int(2.0 * SCALE), int(2.0 * SCALE), S - 1 - int(2.0 * SCALE), S - 1 - int(2.0 * SCALE)),
        radius=int(54 * SCALE),
        outline=(255, 255, 255, 44),
        width=max(1, int(1.5 * SCALE)),
    )
    canvas.alpha_composite(rim)

    # Horizon sits low, leaving room for a calm mark, not a busy illustration.
    horizon_y = int(166 * SCALE)
    left = int(48 * SCALE)
    right = int(208 * SCALE)

    # Glow under the sun on the horizon.
    sun_center = (int(132 * SCALE), horizon_y)
    glow = radial_glow(int(150 * SCALE), (255, 178, 104), 150)
    glow = glow.filter(ImageFilter.GaussianBlur(int(7 * SCALE)))
    canvas.alpha_composite(
        glow,
        (sun_center[0] - int(75 * SCALE), sun_center[1] - int(78 * SCALE)),
    )

    # Setting sun: upper half above the horizon.
    sun = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    sun_draw = ImageDraw.Draw(sun)
    radius = int(31 * SCALE)
    bbox = (sun_center[0] - radius, sun_center[1] - radius, sun_center[0] + radius, sun_center[1] + radius)
    sun_draw.pieslice(bbox, 180, 360, fill=(255, 196, 128, 255))
    inner_radius = int(22 * SCALE)
    inner_bbox = (
        sun_center[0] - inner_radius,
        sun_center[1] - inner_radius,
        sun_center[0] + inner_radius,
        sun_center[1] + inner_radius,
    )
    sun_draw.pieslice(inner_bbox, 180, 360, fill=(255, 226, 184, 255))
    canvas.alpha_composite(sun)

    # Horizon line: bright near the sun, fading to both edges.
    line = Image.new("RGBA", (right - left, max(1, int(3 * SCALE))), (0, 0, 0, 0))
    line_pixels = line.load()
    width = right - left
    for x in range(width):
        t = x / max(1, width - 1)
        center_distance = abs(t - 0.37)
        alpha = int(max(0.0, 1.0 - center_distance * 1.8) * 210)
        line_pixels[x, 0] = (255, 186, 118, alpha)
        for y in range(1, line.height):
            line_pixels[x, y] = (255, 186, 118, int(alpha * 0.55))
    canvas.alpha_composite(line, (left, horizon_y - line.height // 2))

    # One quiet countdown tick: a thin arc that opens at the top, the way a
    # watch face would show time remaining.
    arc = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    arc_draw = ImageDraw.Draw(arc)
    margin = int(27 * SCALE)
    arc_draw.arc(
        (margin, margin, S - margin, S - margin),
        start=208,
        end=332,
        fill=(255, 199, 137, 120),
        width=int(3.2 * SCALE),
    )
    arc = arc.filter(ImageFilter.GaussianBlur(int(0.5 * SCALE)))
    canvas.alpha_composite(arc)

    # A bright endpoint on the arc, at the 4 o'clock position.
    angle = math.radians(332)
    ring_radius = (S / 2) - margin
    dot_x = S / 2 + math.cos(angle) * ring_radius
    dot_y = S / 2 + math.sin(angle) * ring_radius
    dot = radial_glow(int(20 * SCALE), (255, 214, 160), 255)
    canvas.alpha_composite(dot, (int(dot_x - 10 * SCALE), int(dot_y - 10 * SCALE)))

    # Very subtle top highlight.
    sheen = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    sheen_draw = ImageDraw.Draw(sheen)
    sheen_draw.rounded_rectangle(
        (int(18 * SCALE), int(10 * SCALE), S - int(18 * SCALE), int(96 * SCALE)),
        radius=int(40 * SCALE),
        fill=(255, 255, 255, 9),
    )
    sheen = sheen.filter(ImageFilter.GaussianBlur(int(14 * SCALE)))
    canvas.alpha_composite(Image.composite(sheen, Image.new("RGBA", (S, S), (0, 0, 0, 0)), canvas.getchannel("A")))

    return canvas.resize((SIZE, SIZE), Image.Resampling.LANCZOS)


def main() -> None:
    icon = build()
    icon.save(OUT / "icon.png", format="PNG")
    icon.save(
        OUT / "icon.ico",
        format="ICO",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    print(f"wrote {OUT / 'icon.png'} and {OUT / 'icon.ico'}")


if __name__ == "__main__":
    main()
