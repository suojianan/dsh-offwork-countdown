using System;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using WinForms = System.Windows.Forms;

namespace OffWorkCountdown
{
    /// <summary>
    /// Resolves the work area of the monitor that currently owns a window, so
    /// edge snapping never parks the card behind a taskbar. Coordinates are
    /// converted from physical pixels to WPF DIPs.
    /// </summary>
    internal static class ScreenGeometry
    {
        public static Rect WorkAreaForWindow(Window window)
        {
            if (window == null) return SystemParameters.WorkArea;

            IntPtr handle = new WindowInteropHelper(window).Handle;
            if (handle == IntPtr.Zero) return SystemParameters.WorkArea;

            WinForms.Screen screen = WinForms.Screen.FromHandle(handle);
            if (screen == null) return SystemParameters.WorkArea;

            DpiScale dpi = VisualTreeHelper.GetDpi(window);
            if (dpi.DpiScaleX <= 0.0 || dpi.DpiScaleY <= 0.0)
            {
                return SystemParameters.WorkArea;
            }

            System.Drawing.Rectangle area = screen.WorkingArea;
            return new Rect(
                area.Left / dpi.DpiScaleX,
                area.Top / dpi.DpiScaleY,
                area.Width / dpi.DpiScaleX,
                area.Height / dpi.DpiScaleY);
        }
    }
}
