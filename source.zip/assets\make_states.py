"""Build a contact sheet of the five countdown states for the README / handoff."""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
PREVIEW = ROOT / "preview"
OUT = PREVIEW / "states.png"

W, H = 1400, 980
CARD_W = 360
CELL_W = 440
CELL_H = 360
X0 = 40
Y0 = 120
GAP_X = 20
GAP_Y = 20


def font(size: int, bold: bool = False):
    candidates = [
        Path(r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc"),
        Path(r"C:\Windows\Fonts\segoeui.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def lerp(a, b, t):
    return int(round(a + (b - a) * t))


def gradient(top, bottom):
    image = Image.new("RGB", (1, H))
    px = image.load()
    for y in range(H):
        t = y / (H - 1)
        px[0, y] = (lerp(top[0], bottom[0], t), lerp(top[1], bottom[1], t), lerp(top[2], bottom[2], t))
    return image.resize((W, H), Image.Resampling.BICUBIC)


def main():
    background = gradient((13, 20, 32), (28, 22, 24)).convert("RGBA")
    draw = ImageDraw.Draw(background)

    # Soft warm bloom to tie the sheet to the widget's sunset accent.
    bloom = Image.new("RGBA", (700, 500), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bloom)
    bd.ellipse((0, 0, 700, 500), fill=(226, 137, 76, 32))
    from PIL import ImageFilter
    bloom = bloom.filter(ImageFilter.GaussianBlur(80))
    background.alpha_composite(bloom, (W - 620, H - 420))

    draw.text((48, 44), "五种状态", font=font(30, True), fill=(246, 247, 250, 255))
    draw.text((50, 88), "同一块玻璃，跟着时间换语气", font=font(15), fill=(154, 164, 182, 255))

    states = [
        ("before", "上班前", "距上班 · 冷色"),
        ("working", "工作中", "距下班 · 暖色"),
        ("soon", "最后 10 分钟", "快下班了 · 呼吸"),
        ("over", "下班后", "已下班 · 继续计时"),
        ("rest", "周末", "休息日 · 收起进度"),
    ]

    for index, (name, title, subtitle) in enumerate(states):
        column = index % 3
        row = index // 3
        cell_x = X0 + column * (CELL_W + GAP_X)
        cell_y = Y0 + row * (CELL_H + GAP_Y)

        # A quiet cell plate; the widget's own shadow does the layering.
        plate = Image.new("RGBA", (CELL_W, CELL_H), (0, 0, 0, 0))
        pd = ImageDraw.Draw(plate)
        pd.rounded_rectangle((0, 0, CELL_W - 1, CELL_H - 1), radius=20, fill=(255, 255, 255, 8),
                             outline=(255, 255, 255, 16), width=1)
        background.alpha_composite(plate, (cell_x, cell_y))

        widget = Image.open(PREVIEW / f"{name}.png").convert("RGBA")
        widget = widget.resize((CARD_W, round(widget.height * CARD_W / widget.width)),
                               Image.Resampling.LANCZOS)
        wx = cell_x + (CELL_W - CARD_W) // 2
        wy = cell_y + 18
        background.alpha_composite(widget, (wx, wy))

        draw.text((cell_x + 22, cell_y + 274), title, font=font(20, True),
                  fill=(238, 241, 246, 255))
        draw.text((cell_x + 22, cell_y + 302), subtitle, font=font(14),
                  fill=(148, 159, 177, 255))

    draw.text((W - 300, H - 42), "OffWorkCountdown · 88% opacity",
              font=font(12), fill=(112, 122, 138, 255))

    background.convert("RGB").save(OUT, format="PNG")
    print(f"wrote {OUT}")


if __name__ == "__main__":
    main()
