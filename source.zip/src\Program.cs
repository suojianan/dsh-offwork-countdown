using System;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace OffWorkCountdown
{
    internal static class Program
    {
        private const string ShowEventName = @"Local\OffWorkCountdown.Show.1";

        private static EventWaitHandle _showEvent;

        [STAThread]
        public static void Main(string[] args)
        {
            try
            {
                Run(args);
            }
            catch (Exception error)
            {
                Log("FATAL " + error);
                try
                {
                    MessageBox.Show(
                        "下班倒计时启动失败。\n\n" + error.Message,
                        "下班倒计时",
                        MessageBoxButton.OK,
                        MessageBoxImage.Error);
                }
                catch (Exception)
                {
                    // If even the message box cannot open, the log is the fallback.
                }
            }
        }

        private static void Run(string[] args)
        {
            Log("start");
            bool snapshotMode = HasArg(args, "--snapshot");
            bool demoMode = HasArg(args, "--demo");
            string demoState = GetArg(args, "--demo");

            if (demoMode && string.IsNullOrEmpty(demoState))
            {
                demoState = "working";
            }

            if (!snapshotMode)
            {
                bool createdNew;
                _showEvent = new EventWaitHandle(
                    false, EventResetMode.AutoReset, ShowEventName, out createdNew);
                if (!createdNew)
                {
                    try
                    {
                        using (EventWaitHandle existing = EventWaitHandle.OpenExisting(ShowEventName))
                        {
                            existing.Set();
                        }
                    }
                    catch (Exception)
                    {
                        // If the first instance is already gone, just let this one run.
                    }
                    return;
                }
            }

            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                Log("UNHANDLED " + e.ExceptionObject);
            };

            Application app = new Application();
            app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
            app.DispatcherUnhandledException += delegate(object sender, DispatcherUnhandledExceptionEventArgs e)
            {
                Log("DISPATCHER " + e.Exception);
            };
            app.Resources.MergedDictionaries.Add(Xaml.Theme());
            Log("theme loaded");

            AppSettings settings = (snapshotMode || demoMode)
                ? new AppSettings()
                : SettingsStore.Load();

            WidgetWindow window = new WidgetWindow(settings, demoState, snapshotMode);
            app.MainWindow = window;
            window.Show();
            Log("window shown; demo=" + (demoState ?? "off") + "; snapshot=" + snapshotMode);

            if (snapshotMode)
            {
                string path = GetArg(args, "--snapshot");
                if (string.IsNullOrEmpty(path))
                {
                    path = Path.Combine("preview", "snapshot.png");
                }

                DispatcherTimer timer = new DispatcherTimer();
                timer.Interval = TimeSpan.FromMilliseconds(600);
                timer.Tick += delegate
                {
                    timer.Stop();
                    try
                    {
                        window.SaveSnapshot(path);
                    }
                    catch (Exception error)
                    {
                        Log("SNAPSHOT " + error);
                    }
                    window.CloseForSnapshot();
                    app.Shutdown();
                };
                timer.Start();
            }
            else
            {
                StartShowListener(app, window);
            }

            app.Run();

            if (_showEvent != null)
            {
                _showEvent.Dispose();
                _showEvent = null;
            }
        }

        private static void StartShowListener(Application app, WidgetWindow window)
        {
            Thread thread = new Thread(delegate()
            {
                while (true)
                {
                    try
                    {
                        _showEvent.WaitOne();
                    }
                    catch (ObjectDisposedException)
                    {
                        return;
                    }
                    catch (Exception)
                    {
                        return;
                    }

                    try
                    {
                        app.Dispatcher.BeginInvoke(new Action(delegate { window.ShowFromSecondInstance(); }));
                    }
                    catch (Exception)
                    {
                        return;
                    }
                }
            });
            thread.IsBackground = true;
            thread.Name = "OffWorkCountdown.ShowListener";
            thread.Start();
        }

        private static bool HasArg(string[] args, string name)
        {
            foreach (string arg in args)
            {
                if (string.Equals(arg, name, StringComparison.OrdinalIgnoreCase)) return true;
                if (arg.StartsWith(name + "=", StringComparison.OrdinalIgnoreCase)) return true;
            }
            return false;
        }

        private static void Log(string message)
        {
            string line = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "  " + message + Environment.NewLine;
            try
            {
                string folder = SettingsStore.DirectoryPath;
                Directory.CreateDirectory(folder);
                File.AppendAllText(Path.Combine(folder, "startup.log"), line);
            }
            catch (Exception)
            {
                try
                {
                    File.AppendAllText(
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "startup.log"), line);
                }
                catch (Exception)
                {
                    // Diagnostics must never become a failure source.
                }
            }
        }

        private static string GetArg(string[] args, string name)
        {
            for (int index = 0; index < args.Length; index++)
            {
                string arg = args[index];
                if (string.Equals(arg, name, StringComparison.OrdinalIgnoreCase))
                {
                    if (index + 1 < args.Length && !args[index + 1].StartsWith("--", StringComparison.Ordinal))
                    {
                        return args[index + 1];
                    }
                    return null;
                }
                if (arg.StartsWith(name + "=", StringComparison.OrdinalIgnoreCase))
                {
                    return arg.Substring(name.Length + 1);
                }
            }
            return null;
        }
    }
}
