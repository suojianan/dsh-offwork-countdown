using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using FontFamily = System.Windows.Media.FontFamily;

namespace OffWorkCountdown
{
    public sealed class SettingsWindow : Window
    {
        private readonly AppSettings _settings;
        private readonly AppSettings _original;
        private readonly WidgetWindow _owner;
        private readonly Grid _root;
        private readonly TextBox _startField;
        private readonly TextBox _endField;
        private readonly CheckBox _workdaysCheck;
        private readonly CheckBox _topmostCheck;
        private readonly Slider _opacitySlider;
        private readonly TextBlock _opacityValue;
        private readonly TextBlock _errorText;
        private bool _saved;
        private bool _initializing;

        public SettingsWindow(AppSettings settings, WidgetWindow owner)
        {
            _settings = settings;
            _original = settings.Clone();
            _owner = owner;

            Width = 344;
            Height = 360;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ResizeMode = ResizeMode.NoResize;
            ShowInTaskbar = false;
            Topmost = true;
            FontFamily = new FontFamily("Microsoft YaHei UI");
            SnapsToDevicePixels = true;
            UseLayoutRounding = true;

            _root = (Grid)Xaml.Load("OffWorkCountdown.ui.SettingsWindow.xaml");
            _root.Background = Brushes.Transparent;
            Content = _root;

            _startField = Find<TextBox>(_root, "StartField");
            _endField = Find<TextBox>(_root, "EndField");
            _workdaysCheck = Find<CheckBox>(_root, "WorkdaysCheck");
            _topmostCheck = Find<CheckBox>(_root, "TopmostCheck");
            _opacitySlider = Find<Slider>(_root, "OpacitySlider");
            _opacityValue = Find<TextBlock>(_root, "OpacityValue");
            _errorText = Find<TextBlock>(_root, "ErrorText");

            _startField.Text = CountdownEngine.FormatMinutes(settings.StartMinutes);
            _endField.Text = CountdownEngine.FormatMinutes(settings.EndMinutes);
            _workdaysCheck.IsChecked = settings.WorkdaysOnly;
            _topmostCheck.IsChecked = settings.Topmost;
            _opacitySlider.Value = settings.Opacity * 100.0;
            _opacityValue.Text = ((int)Math.Round(_opacitySlider.Value)) + "%";
            _errorText.Text = string.Empty;

            Button closeButton = Find<Button>(_root, "CloseButton");
            Button cancelButton = Find<Button>(_root, "CancelButton");
            Button saveButton = Find<Button>(_root, "SaveButton");
            Button resetButton = Find<Button>(_root, "ResetButton");

            closeButton.Click += delegate { Cancel(); };
            cancelButton.Click += delegate { Cancel(); };
            saveButton.Click += delegate { Save(); };
            resetButton.Click += delegate { Reset(); };

            _startField.PreviewTextInput += OnPreviewTimeInput;
            _endField.PreviewTextInput += OnPreviewTimeInput;
            _startField.GotKeyboardFocus += delegate { _startField.SelectAll(); };
            _endField.GotKeyboardFocus += delegate { _endField.SelectAll(); };
            _startField.KeyDown += OnFieldKeyDown;
            _endField.KeyDown += OnFieldKeyDown;
            _startField.TextChanged += delegate { _errorText.Text = string.Empty; };
            _endField.TextChanged += delegate { _errorText.Text = string.Empty; };

            _opacitySlider.ValueChanged += OnOpacityChanged;

            Grid headerBar = Find<Grid>(_root, "HeaderBar");
            headerBar.MouseLeftButtonDown += delegate
            {
                try
                {
                    DragMove();
                }
                catch (InvalidOperationException)
                {
                    // A stray double-click on the header is harmless.
                }
            };

            Loaded += OnLoaded;
            Closing += OnClosing;
        }

        private static T Find<T>(FrameworkElement root, string name) where T : class
        {
            T value = root.FindName(name) as T;
            if (value == null)
            {
                throw new InvalidOperationException("Missing element in SettingsWindow.xaml: " + name);
            }
            return value;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            Rect work = ScreenGeometry.WorkAreaForWindow(_owner);
            Left = _owner.Left + _owner.Width - Width;
            Top = _owner.Top - Height - 10;

            if (Top < work.Top + 8)
            {
                Top = _owner.Top + _owner.Height + 10;
            }
            if (Left < work.Left + 8) Left = work.Left + 8;
            if (Left + Width > work.Right - 8) Left = work.Right - Width - 8;
            if (Top + Height > work.Bottom - 8) Top = work.Bottom - Height - 8;

            _startField.Focus();
            _startField.SelectAll();
        }

        private void OnClosing(object sender, CancelEventArgs e)
        {
            if (!_saved)
            {
                _owner.PreviewGlassOpacity(_original.Opacity);
            }
        }

        private void OnOpacityChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (_initializing) return;
            _opacityValue.Text = ((int)Math.Round(_opacitySlider.Value)) + "%";
            _owner.PreviewGlassOpacity(_opacitySlider.Value / 100.0);
        }

        private void OnPreviewTimeInput(object sender, TextCompositionEventArgs e)
        {
            foreach (char character in e.Text)
            {
                if (!char.IsDigit(character) && character != ':' && character != '：')
                {
                    e.Handled = true;
                    return;
                }
            }
        }

        private void OnFieldKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                Save();
                e.Handled = true;
            }
            else if (e.Key == Key.Escape)
            {
                Cancel();
                e.Handled = true;
            }
        }

        private void Save()
        {
            int start;
            int end;
            if (!CountdownEngine.TryParseMinutes(_startField.Text, out start))
            {
                ShowError("上班时间格式不对，请用 09:00 这样的格式", _startField);
                return;
            }
            if (!CountdownEngine.TryParseMinutes(_endField.Text, out end))
            {
                ShowError("下班时间格式不对，请用 09:00 这样的格式", _endField);
                return;
            }
            if (end <= start)
            {
                ShowError("下班时间需要晚于上班时间", _endField);
                return;
            }

            AppSettings next = _settings.Clone();
            next.StartMinutes = start;
            next.EndMinutes = end;
            next.WorkdaysOnly = _workdaysCheck.IsChecked == true;
            next.Topmost = _topmostCheck.IsChecked == true;
            next.Opacity = _opacitySlider.Value / 100.0;

            _saved = true;
            _owner.ApplySettings(next);
            Close();
        }

        private void Cancel()
        {
            _saved = true;
            _owner.PreviewGlassOpacity(_original.Opacity);
            Close();
        }

        private void Reset()
        {
            _initializing = true;
            _startField.Text = CountdownEngine.FormatMinutes(AppSettings.DefaultStartMinutes);
            _endField.Text = CountdownEngine.FormatMinutes(AppSettings.DefaultEndMinutes);
            _workdaysCheck.IsChecked = true;
            _topmostCheck.IsChecked = true;
            _opacitySlider.Value = AppSettings.DefaultOpacity * 100.0;
            _opacityValue.Text = ((int)Math.Round(AppSettings.DefaultOpacity * 100.0)) + "%";
            _errorText.Text = string.Empty;
            _initializing = false;
            _owner.PreviewGlassOpacity(AppSettings.DefaultOpacity);
        }

        private void ShowError(string message, TextBox focusField)
        {
            _errorText.Text = message;
            focusField.Focus();
            focusField.SelectAll();
        }
    }
}
