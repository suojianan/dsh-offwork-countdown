$ErrorActionPreference = "Stop"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$out = Join-Path $root "OffWorkCountdown.exe"

$running = Get-Process OffWorkCountdown -ErrorAction SilentlyContinue
if ($running) {
    throw "OffWorkCountdown.exe is running. Exit it from the tray, then rebuild."
}

$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path $csc)) {
    throw "csc.exe not found at $csc"
}

$framework = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319"
$gacRoots = @(
    (Join-Path $env:WINDIR "Microsoft.NET\assembly\GAC_MSIL"),
    (Join-Path $env:WINDIR "Microsoft.NET\assembly\GAC_64"),
    (Join-Path $env:WINDIR "Microsoft.NET\assembly\GAC_32")
)

function Find-GacAssembly([string]$name) {
    foreach ($gac in $gacRoots) {
        if (-not (Test-Path $gac)) { continue }
        $candidate = Get-ChildItem (Join-Path $gac $name) -Recurse -Filter "$name.dll" -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($candidate) { return $candidate.FullName }
    }
    throw "Could not locate $name.dll in the GAC"
}

$references = @(
    (Join-Path $framework "System.dll"),
    (Join-Path $framework "System.Core.dll"),
    (Join-Path $framework "System.Drawing.dll"),
    (Join-Path $framework "System.Windows.Forms.dll"),
    (Find-GacAssembly "PresentationFramework"),
    (Find-GacAssembly "PresentationCore"),
    (Find-GacAssembly "WindowsBase"),
    (Find-GacAssembly "System.Xaml")
)

$sources = Get-ChildItem (Join-Path $root "src") -Filter "*.cs" | ForEach-Object { $_.FullName }

$arguments = @(
    "/nologo",
    "/target:winexe",
    "/platform:x64",
    "/optimize+",
    "/codepage:65001",
    "/utf8output",
    "/out:$out",
    "/win32manifest:$root\app.manifest",
    ("/win32icon:" + (Join-Path $root "assets\icon.ico")),
    ("/resource:" + (Join-Path $root "ui\Theme.xaml") + ",OffWorkCountdown.ui.Theme.xaml"),
    ("/resource:" + (Join-Path $root "ui\WidgetWindow.xaml") + ",OffWorkCountdown.ui.WidgetWindow.xaml"),
    ("/resource:" + (Join-Path $root "ui\SettingsWindow.xaml") + ",OffWorkCountdown.ui.SettingsWindow.xaml"),
    ("/resource:" + (Join-Path $root "assets\icon.ico") + ",OffWorkCountdown.assets.icon.ico")
)

foreach ($reference in $references) {
    $arguments += "/r:$reference"
}
$arguments += $sources

Write-Host "Compiling $out ..."
& $csc $arguments
if ($LASTEXITCODE -ne 0) {
    throw "Compilation failed with exit code $LASTEXITCODE"
}

$info = Get-Item $out
Write-Host ("Built {0} ({1:N0} bytes)" -f $info.Name, $info.Length)
